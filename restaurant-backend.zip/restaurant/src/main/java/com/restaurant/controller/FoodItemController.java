package com.restaurant.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.exception.ResourceNotFoundException;
import com.restaurant.model.FoodItem;
import com.restaurant.service.FoodItemService;

//@CrossOrigin(origins = "http://localhost:4200")
@CrossOrigin("*")
@RestController
@RequestMapping("/food")
public class FoodItemController {
		
	@Autowired
	private FoodItemService foodItemService;
	
	//get all food items
	
	@GetMapping("/foodItems")
	public List<FoodItem> getAllFoodItems(){
		return this.foodItemService.getAllFoodItems();
	}
	
	// create fooditem rest api
	@PostMapping("/foodItems")
	public FoodItem createEmployee(@RequestBody FoodItem foodItem) {
		return this.foodItemService.createFoodItem(foodItem);
	}
	
	// get fooditem by id rest api
	@GetMapping("/foodItems/{id}")
	public ResponseEntity<FoodItem> getFoodItemById(@PathVariable Long id) {
		return this.foodItemService.getFoodItemById(id);
	}
	
	// update fooditem rest api
	@PutMapping("/foodItems/{id}")
	public ResponseEntity<FoodItem> updateFoodItem(@PathVariable Long id, @RequestBody FoodItem foodItemDetails){
		return this.foodItemService.updateFoodItem(id, foodItemDetails);
	}
	
	// delete fooditem rest api
	@DeleteMapping("/foodItems/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteFoodItem(@PathVariable Long id){
		return this.foodItemService.deleteFoodItem(id);
	}
}
