package com.restaurant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.model.Customer;
import com.restaurant.model.FoodItem;
import com.restaurant.service.CustomerService;
import com.restaurant.service.FoodItemService;

@RestController
@RequestMapping
//@CrossOrigin(origins = "http://localhost:4200")
@CrossOrigin("*")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	
	//get all customers
	
	@GetMapping("/customers")
	public List<Customer> getAllCustomers(){
		return this.customerService.getAllCustomers();
	}
	
	// create customer
	@PostMapping("/customer")
	public Customer createCustomer(@RequestBody Customer customer) {
		return this.customerService.createCustomer(customer);
	}
	
	// get customer by id rest api
	@GetMapping("/customer/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable Long id) {
		return this.customerService.getCustomerById(id);
	}
}
