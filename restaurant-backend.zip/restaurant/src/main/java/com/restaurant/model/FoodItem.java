package com.restaurant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "food_items")
public class FoodItem {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long foodId;
	
	@Column(name = "name")
	private String name;

	@Column(name = "image_path")
	private String imagePath;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "price")
	private String price;

	
	
	public FoodItem() {
		super();
	}



	public FoodItem(long foodId, String name, String imagePath, String description, String price) {
		super();
		this.foodId = foodId;
		this.name = name;
		this.imagePath = imagePath;
		this.description = description;
		this.price = price;
	}



	public long getFoodId() {
		return foodId;
	}



	public void setFoodId(long foodId) {
		this.foodId = foodId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getImagePath() {
		return imagePath;
	}



	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getPrice() {
		return price;
	}



	public void setPrice(String price) {
		this.price = price;
	}

	

	
	
	
	

}
