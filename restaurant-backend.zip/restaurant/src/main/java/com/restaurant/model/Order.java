package com.restaurant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "order1")
public class Order {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long orderId;
    private String userName;
    private String bill;
    private String date;
    private boolean status;
    
    
	public Order() {
		super();
	}
	public Order(Long orderId, String userName, String bill, String date, boolean status) {
		super();
		this.orderId = orderId;
		this.userName = userName;
		this.bill = bill;
		this.date = date;
		this.status = status;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBill() {
		return bill;
	}
	public void setBill(String bill) {
		this.bill = bill;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}


	
    
}
