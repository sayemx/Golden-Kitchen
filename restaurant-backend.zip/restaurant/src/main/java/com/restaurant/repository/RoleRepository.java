package com.restaurant.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.restaurant.model.Role;

public interface RoleRepository extends JpaRepository<Role,Long> {
}
