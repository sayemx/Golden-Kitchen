package com.restaurant.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.restaurant.exception.ResourceNotFoundException;
import com.restaurant.model.Customer;
import com.restaurant.model.FoodItem;
import com.restaurant.repository.CustomerRepository;
import com.restaurant.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;
	
	@Override
	public List<Customer> getAllCustomers() {
		return this.customerRepository.findAll();
	}

	@Override
	public Customer createCustomer(Customer customer) {
		return this.customerRepository.save(customer);
	}

	@Override
	public ResponseEntity<Customer> getCustomerById(Long id) {
		Customer customer = this.customerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer does not exist with id :" + id));
		return ResponseEntity.ok(customer);
	}

}
