package com.restaurant.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.restaurant.exception.ResourceNotFoundException;
import com.restaurant.model.FoodItem;
import com.restaurant.repository.FoodItemRepository;
import com.restaurant.service.FoodItemService;

@Service
public class FoodItemImpl implements FoodItemService{

	@Autowired
	FoodItemRepository foodItemRepository;
	
	@Override
	public List<FoodItem> getAllFoodItems() {
		return this.foodItemRepository.findAll();
	}

	@Override
	public FoodItem createFoodItem(FoodItem foodItem) {
		return this.foodItemRepository.save(foodItem);
		
	}

	@Override
	public ResponseEntity<FoodItem> getFoodItemById(Long id) {
		FoodItem foodItem = this.foodItemRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("FoodItem does not exist with id :" + id));
		return ResponseEntity.ok(foodItem);
	}

	@Override
	public ResponseEntity<FoodItem> updateFoodItem(Long id, FoodItem foodItemDetails) {
		FoodItem foodItem = this.foodItemRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Food does not exist with id :" + id));
		
		foodItem.setName(foodItemDetails.getName());
		foodItem.setImagePath(foodItemDetails.getImagePath());
		foodItem.setDescription(foodItemDetails.getDescription());
		foodItem.setPrice(foodItemDetails.getPrice());
		FoodItem updatedFoodItem = this.foodItemRepository.save(foodItem);
		return ResponseEntity.ok(updatedFoodItem);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> deleteFoodItem(Long id){
		FoodItem foodItem = this.foodItemRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("FoodItem does not exist with id :" + id));
		
		this.foodItemRepository.delete(foodItem);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

}
