package com.restaurant.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.restaurant.model.Customer;

public interface CustomerService {
	
	public List<Customer> getAllCustomers();
	public Customer createCustomer(Customer customer);
	public ResponseEntity<Customer> getCustomerById(Long id);
//	public ResponseEntity<FoodItem> updateFoodItem(Long id,  FoodItem foodItemDetails);
//	public ResponseEntity<Map<String, Boolean>> deleteFoodItem(Long id);

}
