package com.restaurant.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.restaurant.model.FoodItem;
import com.restaurant.model.Order;
import com.restaurant.model.User;

public interface OrderService {
	public List<Order> getAllOrders();
	public Order createOrder(Order order);
	public ResponseEntity<Map<String, Boolean>> deleteByOrderId(Long id);
	public ResponseEntity<Order> updateOrder(Long id);
}
