package com.restaurant.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.restaurant.model.FoodItem;

public interface FoodItemService {
	public List<FoodItem> getAllFoodItems();
	public FoodItem createFoodItem(FoodItem foodItem);
	public ResponseEntity<FoodItem> getFoodItemById(Long id);
	public ResponseEntity<FoodItem> updateFoodItem(Long id,  FoodItem foodItemDetails);
	public ResponseEntity<Map<String, Boolean>> deleteFoodItem(Long id);
	
}
