package com.restaurant.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.restaurant.exception.ResourceNotFoundException;
import com.restaurant.model.FoodItem;
import com.restaurant.model.Order;
import com.restaurant.repository.OrderRepository;
import com.restaurant.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderRepository orderRepository;
	
	@Override
	public List<Order> getAllOrders() {
		return this.orderRepository.findAll(); 
	}

	@Override
	public Order createOrder(Order order) {
		return this.orderRepository.save(order);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> deleteByOrderId(Long id) {
		Order order = this.orderRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Order does not exist with id :" + id));
		
		this.orderRepository.delete(order);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	@Override
	public ResponseEntity<Order> updateOrder(Long id) {
		Order order = this.orderRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Order does not exist with id :" + id));
		
		order.setStatus(true);
		Order updatedOrder = this.orderRepository.save(order);
		return ResponseEntity.ok(updatedOrder);
	}

}
